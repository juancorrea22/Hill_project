(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/7d65b_next_ef9a42b1._.js",
  "static/chunks/Hill_project_frontend_app_ce3a9e05._.js",
  "static/chunks/Hill_project_frontend_app_login_Pages_module_6141548d.css"
],
    source: "dynamic"
});
