(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/7d65b_next_dist_compiled_a0a35726._.js",
  "static/chunks/7d65b_next_dist_shared_lib_4e2da387._.js",
  "static/chunks/7d65b_next_dist_client_adab7f91._.js",
  "static/chunks/7d65b_next_dist_745d0ae7._.js",
  "static/chunks/7d65b_next_error_933f6e7a.js",
  "static/chunks/[next]_entry_page-loader_ts_827b27c4._.js",
  "static/chunks/7d65b_react-dom_331c8017._.js",
  "static/chunks/7d65b_848604dd._.js",
  "static/chunks/[root-of-the-server]__2dae1975._.js"
],
    source: "entry"
});
