__turbopack_load_page_chunks__("/_app", [
  "static/chunks/7d65b_next_dist_compiled_a0a35726._.js",
  "static/chunks/7d65b_next_dist_shared_lib_93681878._.js",
  "static/chunks/7d65b_next_dist_client_adab7f91._.js",
  "static/chunks/7d65b_next_dist_4cefeba8._.js",
  "static/chunks/7d65b_next_app_6976cd3e.js",
  "static/chunks/[next]_entry_page-loader_ts_bc275f62._.js",
  "static/chunks/7d65b_react-dom_331c8017._.js",
  "static/chunks/7d65b_848604dd._.js",
  "static/chunks/[root-of-the-server]__06b57935._.js",
  "static/chunks/Hill_project_frontend_pages__app_2da965e7._.js",
  "static/chunks/turbopack-Hill_project_frontend_pages__app_dd6a38d0._.js"
])
