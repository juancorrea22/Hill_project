(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/7d65b_next_465016b7._.js",
  "static/chunks/Hill_project_frontend_app_home_216ab7a8._.js",
  "static/chunks/Hill_project_frontend_app_home_Home_module_146d5b1f.css"
],
    source: "dynamic"
});
