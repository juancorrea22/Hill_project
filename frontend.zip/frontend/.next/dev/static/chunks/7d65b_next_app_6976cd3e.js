(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Hill_project/frontend/node_modules/next/app.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/Hill_project/frontend/node_modules/next/dist/pages/_app.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=7d65b_next_app_6976cd3e.js.map