(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/7d65b_next_5ae3f725._.js",
  "static/chunks/Hill_project_frontend_app_opciones_page_tsx_d1c6f716._.js",
  "static/chunks/Hill_project_frontend_src_styles_opciones_a128d5cb.css"
],
    source: "dynamic"
});
