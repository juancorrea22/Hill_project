(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/7d65b_next_465016b7._.js",
  "static/chunks/Hill_project_frontend_app_notificaciones_35f702be._.js",
  "static/chunks/Hill_project_frontend_app_notificaciones_Notificaciones_module_25981402.css"
],
    source: "dynamic"
});
