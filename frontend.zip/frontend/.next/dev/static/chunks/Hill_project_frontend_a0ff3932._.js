(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_e74e1665._.js",
  "static/chunks/7d65b_next_dist_compiled_react-dom_6d690f44._.js",
  "static/chunks/7d65b_next_dist_compiled_react-server-dom-turbopack_ed726c8f._.js",
  "static/chunks/7d65b_next_dist_compiled_next-devtools_index_3c50d50c.js",
  "static/chunks/7d65b_next_dist_compiled_ffdc6ff1._.js",
  "static/chunks/7d65b_next_dist_client_9a2a9b29._.js",
  "static/chunks/7d65b_next_dist_1b2355ac._.js",
  "static/chunks/7d65b_@swc_helpers_cjs_c5d43dca._.js"
],
    source: "entry"
});
