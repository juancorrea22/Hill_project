module.exports = [
"[project]/Hill_project/frontend/src/styles/pages.module.css [app-rsc] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "hill-login__links": "pages-module__C7w0fq__hill-login__links",
  "hill_avatar": "pages-module__C7w0fq__hill_avatar",
  "hill_banner": "pages-module__C7w0fq__hill_banner",
  "hill_btn": "pages-module__C7w0fq__hill_btn",
  "hill_btn--full-width": "pages-module__C7w0fq__hill_btn--full-width",
  "hill_btn__primary": "pages-module__C7w0fq__hill_btn__primary",
  "hill_chart": "pages-module__C7w0fq__hill_chart",
  "hill_form": "pages-module__C7w0fq__hill_form",
  "hill_form_error_message": "pages-module__C7w0fq__hill_form_error_message",
  "hill_form_group": "pages-module__C7w0fq__hill_form_group",
  "hill_form_input": "pages-module__C7w0fq__hill_form_input",
  "hill_form_label": "pages-module__C7w0fq__hill_form_label",
  "hill_icon": "pages-module__C7w0fq__hill_icon",
  "hill_image": "pages-module__C7w0fq__hill_image",
  "hill_image--contain": "pages-module__C7w0fq__hill_image--contain",
  "hill_image_placeholder": "pages-module__C7w0fq__hill_image_placeholder",
  "hill_login__form_container": "pages-module__C7w0fq__hill_login__form_container",
  "hill_login__image": "pages-module__C7w0fq__hill_login__image",
  "hill_login__link": "pages-module__C7w0fq__hill_login__link",
  "hill_login__links": "pages-module__C7w0fq__hill_login__links",
  "hill_login__logo": "pages-module__C7w0fq__hill_login__logo",
  "hill_login__title": "pages-module__C7w0fq__hill_login__title",
  "hill_login_container": "pages-module__C7w0fq__hill_login_container",
  "hill_login_page": "pages-module__C7w0fq__hill_login_page",
  "hill_logo": "pages-module__C7w0fq__hill_logo",
  "hill_logo_placeholder": "pages-module__C7w0fq__hill_logo_placeholder",
});
}),
"[project]/Hill_project/frontend/app/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RootLayout,
    "metadata",
    ()=>metadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Hill_project/frontend/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$src$2f$styles$2f$pages$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/Hill_project/frontend/src/styles/pages.module.css [app-rsc] (css module)");
;
;
;
;
;
;
const metadata = {
    title: 'Hill',
    description: 'Hill - seguimiento de hábitos'
};
function RootLayout({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("html", {
        lang: "es",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("body", {
            children: children
        }, void 0, false, {
            fileName: "[project]/Hill_project/frontend/app/layout.tsx",
            lineNumber: 17,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Hill_project/frontend/app/layout.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
}),
"[project]/Hill_project/frontend/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/Hill_project/frontend/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-rsc] (ecmascript)").vendored['react-rsc'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}),
];

//# sourceMappingURL=Hill_project_frontend_15b2ff26._.js.map