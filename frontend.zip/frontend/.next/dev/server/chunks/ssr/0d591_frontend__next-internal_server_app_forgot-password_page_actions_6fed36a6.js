module.exports = [
"[project]/Hill_project/frontend/.next-internal/server/app/forgot-password/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=0d591_frontend__next-internal_server_app_forgot-password_page_actions_6fed36a6.js.map