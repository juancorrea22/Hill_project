module.exports = [
"[project]/Hill_project/frontend/.next-internal/server/app/login/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=Hill_project_frontend__next-internal_server_app_login_page_actions_19900728.js.map