module.exports = [
"[project]/Hill_project/frontend/.next-internal/server/app/home/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=Hill_project_frontend__next-internal_server_app_home_page_actions_6b7bfd78.js.map