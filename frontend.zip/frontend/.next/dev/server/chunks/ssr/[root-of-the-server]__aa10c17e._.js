module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/Hill_project/frontend/app/login/Pages.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "hill_avatar": "Pages-module__jl5xqa__hill_avatar",
  "hill_banner": "Pages-module__jl5xqa__hill_banner",
  "hill_btn": "Pages-module__jl5xqa__hill_btn",
  "hill_btn__full-width": "Pages-module__jl5xqa__hill_btn__full-width",
  "hill_btn__primary": "Pages-module__jl5xqa__hill_btn__primary",
  "hill_chart": "Pages-module__jl5xqa__hill_chart",
  "hill_form": "Pages-module__jl5xqa__hill_form",
  "hill_form_error_message": "Pages-module__jl5xqa__hill_form_error_message",
  "hill_form_group": "Pages-module__jl5xqa__hill_form_group",
  "hill_form_input": "Pages-module__jl5xqa__hill_form_input",
  "hill_form_label": "Pages-module__jl5xqa__hill_form_label",
  "hill_icon": "Pages-module__jl5xqa__hill_icon",
  "hill_image": "Pages-module__jl5xqa__hill_image",
  "hill_image--contain": "Pages-module__jl5xqa__hill_image--contain",
  "hill_image_placeholder": "Pages-module__jl5xqa__hill_image_placeholder",
  "hill_login__form_container": "Pages-module__jl5xqa__hill_login__form_container",
  "hill_login__image": "Pages-module__jl5xqa__hill_login__image",
  "hill_login__link": "Pages-module__jl5xqa__hill_login__link",
  "hill_login__links": "Pages-module__jl5xqa__hill_login__links",
  "hill_login__logo": "Pages-module__jl5xqa__hill_login__logo",
  "hill_login__title": "Pages-module__jl5xqa__hill_login__title",
  "hill_login_container": "Pages-module__jl5xqa__hill_login_container",
  "hill_login_page": "Pages-module__jl5xqa__hill_login_page",
  "hill_logo": "Pages-module__jl5xqa__hill_logo",
  "hill_logo_placeholder": "Pages-module__jl5xqa__hill_logo_placeholder",
});
}),
"[project]/Hill_project/frontend/app/forgot-password/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ForgotPasswordPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Hill_project/frontend/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Hill_project/frontend/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Hill_project/frontend/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Hill_project/frontend/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/Hill_project/frontend/app/login/Pages.module.css [app-ssr] (css module)");
'use client';
;
;
;
;
;
function ForgotPasswordPage() {
    const [email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [success, setSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    async function handleSubmit(e) {
        e.preventDefault();
        setError(false);
        setSuccess(false);
        const API = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:4000';
        try {
            const response = await fetch(`${API}/api/auth/forgot-password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    email
                })
            });
            if (response.ok) {
                setSuccess(true);
            } else {
                setError(true);
            }
        } catch (err) {
            console.error('Error al recuperar contraseña:', err);
            setError(true);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_login_page,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_login_container,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_login__image,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: "/login-image.jpg",
                        width: 626,
                        height: 626,
                        alt: "hábitos saludables",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_image
                    }, void 0, false, {
                        fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                        lineNumber: 42,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_login__form_container,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_login__logo,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: "/Hill_imagen_logo.jpg",
                                width: 60,
                                height: 60,
                                alt: "logo hill",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_logo
                            }, void 0, false, {
                                fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                lineNumber: 47,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_login__form,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_login__title,
                                    children: "Recuperar Contraseña"
                                }, void 0, false, {
                                    fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    style: {
                                        textAlign: 'center',
                                        color: '#666',
                                        marginBottom: '20px',
                                        fontSize: '14px'
                                    },
                                    children: "Ingresa tu correo electrónico y te enviaremos instrucciones para restablecer tu contraseña."
                                }, void 0, false, {
                                    fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                    lineNumber: 52,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_form,
                                    onSubmit: handleSubmit,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_form_group,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    htmlFor: "email",
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_form_label,
                                                    children: "Correo electrónico"
                                                }, void 0, false, {
                                                    fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                                    lineNumber: 58,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "email",
                                                    id: "email",
                                                    name: "email",
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_form_input,
                                                    value: email,
                                                    onChange: (e)=>setEmail(e.target.value),
                                                    required: true
                                                }, void 0, false, {
                                                    fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                                    lineNumber: 59,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                            lineNumber: 57,
                                            columnNumber: 15
                                        }, this),
                                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_form,
                                            children: "No se encontró una cuenta con este correo electrónico"
                                        }, void 0, false, {
                                            fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                            lineNumber: 62,
                                            columnNumber: 26
                                        }, this),
                                        success && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_form,
                                            style: {
                                                color: '#28a745',
                                                textAlign: 'center',
                                                marginBottom: '15px',
                                                fontSize: '14px'
                                            },
                                            children: "Se ha enviado un correo con instrucciones para recuperar tu contraseña"
                                        }, void 0, false, {
                                            fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                            lineNumber: 63,
                                            columnNumber: 28
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "submit",
                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_btn} ${__TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_btn__primary} ${__TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_btn__full_width}`,
                                            children: "Enviar instrucciones"
                                        }, void 0, false, {
                                            fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                    lineNumber: 56,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_login__links,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: "/login",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_login__link,
                                            children: "Volver a iniciar sesión"
                                        }, void 0, false, {
                                            fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                            lineNumber: 69,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: "/sign-in",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$Hill_project$2f$frontend$2f$app$2f$login$2f$Pages$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hill_login__link,
                                            children: "Crear una cuenta"
                                        }, void 0, false, {
                                            fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                            lineNumber: 70,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                                    lineNumber: 68,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                            lineNumber: 50,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
            lineNumber: 40,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Hill_project/frontend/app/forgot-password/page.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__aa10c17e._.js.map