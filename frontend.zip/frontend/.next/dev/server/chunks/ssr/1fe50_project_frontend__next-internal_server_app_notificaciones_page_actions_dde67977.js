module.exports = [
"[project]/Hill_project/frontend/.next-internal/server/app/notificaciones/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=1fe50_project_frontend__next-internal_server_app_notificaciones_page_actions_dde67977.js.map