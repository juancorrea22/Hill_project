module.exports = [
"[project]/Hill_project/frontend/.next-internal/server/app/opciones/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=Hill_project_frontend__next-internal_server_app_opciones_page_actions_d3b82e24.js.map